<!DOCTYPE html>
<html>

<head>
    <title>Laporan Transaksi Laundry</title>
</head>

<body>
    <style>
        body {
            font-family: sans-serif;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
        }

        table th,
        table td {
            border: 1px solid #3c3c3c;
            padding: 3px 8px;

        }

        a {
            background: blue;
            color: #fff;
            padding: 8px 10px;
            text-decoration: none;
            border-radius: 2px;
        }

        .tengah {
            text-align: center;
        }
    </style>
    <table width = 100%>
        <tr text-align="center">
            Laporan Transaksi Laundry
        </tr>
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Jenis Paket</th>
            <th>QTY</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Total</th>
        </tr>
        <?php
        include "koneksi.php";

        $data = mysqli_query($conn, "select * from transaksi");
        while ($dt_transaksi = mysqli_fetch_array($data)) {
        ?>
            <tr>
                <td style='text-align: center;'><?php echo $dt_transaksi['id_transaksi'] ?></td>
                <?php
                $qry_member = mysqli_query($conn, "select * from transaksi join member on member.id_member=transaksi.id_member where id_transaksi= '" .$dt_transaksi['id_transaksi'] . "'");
                $dt_member = mysqli_fetch_array($qry_member);
                ?>
                <td><?php echo $dt_member['nama_member']; ?></td>
                <?php
                $qry_paket = mysqli_query($conn, "select * from transaksi join paket on paket.id_paket=transaksi.id_paket where id_transaksi='" . $dt_transaksi['id_transaksi'] . "'");
                $dt_paket = mysqli_fetch_array($qry_paket);
                ?>
                <td><?php echo $dt_paket['jenis']; ?></td>
                <td><?php echo $dt_transaksi['qty']; ?></td>
                <td><?php echo $dt_transaksi['tanggal']; ?></td>
                <td><?php echo $dt_transaksi['status']; ?> </td>
                <?php
                $total = $dt_transaksi['qty'] * $dt_paket['harga'];
                ?>
                <td>Rp <?=$total?></td>
            </tr>
        <?php
        }
        ?>
    </table>
    <script>
        window.print();
    </script>
</body>

</html>