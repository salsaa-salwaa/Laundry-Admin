<?php
if($_POST){
    $id_member=$_POST['id_member'];
    $nama_member=$_POST['nama_member'];
    $alamat=$_POST['alamat'];
    $gender=$_POST['gender'];
    $tlp=$_POST['tlp'];

    if(empty($nama_member)){
        echo "<script>alert('nama_member member tidak boleh kosong');location.href='tambah_member.php';</script>";
    } else {
        include "koneksi.php";
        if(empty($nama_member)){
            $update=mysqli_query($conn,"update member set nama_member='".$nama_member."',alamat='".$alamat."', gender='".$gender."', tlp='".$tlp."' where id_member = '".$id_member."' ") or die(mysqli_error($conn));
            if($update){
                echo "<script>alert('Sukses update member');location.href='tampil_member.php';</script>";
            } else {
                echo "<script>alert('Gagal update member');location.href='ubah_member.php?id_member=".$id_member."';</script>";
            }
        } else {
            $update=mysqli_query($conn,"update member set nama_member='".$nama_member."',alamat='".$alamat."', gender='".$gender."', tlp='".$tlp."' where id_member = '".$id_member."'") or die(mysqli_error($conn));
            if($update){
                echo "<script>alert('Sukses update member');location.href='tampil_member.php';</script>";
            } else {
                echo "<script>alert('Gagal update member');location.href='ubah_member.php?id".$id."';</script>";
            }
        }
        
    } 
}
?>