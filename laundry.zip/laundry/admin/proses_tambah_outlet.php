<?php
if ($_POST){
    $nama_outlet = $_POST ['nama_outlet'];
    $alamat_outlet = $_POST ['alamat_outlet'];

    if(empty($nama_outlet)){
        echo "<script>alert('nama outlet tidak boleh kosong');location.href='tambah_outlet.php';</script>";
    } elseif(empty($alamat_outlet)){
        echo "<script>alert('alamat_outlet tidak boleh kosong');location.href='tambah_outlet.php';</script>";
    } else {
        include "koneksi.php";
        $insert= mysqli_query($conn,"insert into outlet (nama_outlet, alamat_outlet) value ('".$nama_outlet."','".$alamat_outlet."')") or die(mysqli_error($conn));
        if($insert){
            echo "<script>alert('Sukses menambahkan outlet');location.href='tampil_outlet.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan outlet');location.href='tambah_outlet.php';</script>";
        }
    }
}
?>

