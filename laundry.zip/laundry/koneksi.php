<?php
/* adalah nama fungsi php untuk menjalankan argumen agar terkoneksi ke server mysql dan atau database. */
/*localhost adalah alamat lokasi MySQL Server dijalankan.*/
/*argumen nama user MySQL dimana kita akan login. Di dalam server, user ini dapat kita tambah, 
hapus, dan edit*/
$conn=mysqli_connect('localhost','root','','laundry');

/* check connection */
if (mysqli_connect_error()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>